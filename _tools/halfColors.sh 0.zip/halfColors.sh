#!/bin/bash



function parseColors {
fileCat="$3"
startLine="$2"
doRecurse="$1"
indent=0
startLineFound=0



if [ "$doRecurse" == "0" ]
then
	echo "looking for '$startLine'"
	indent=3
fi

IFS="
"

shopt -s extglob

for line in $fileCat
do
#echo "$line"

	if [ "$doRecurse" == "0" ]
	then
		if [ "$startLineFound" == "0" ]
		then
			if [ "$line" == "$startLine" ]
			then
				echo "...found"
				startLineFound=1
			fi

			continue
		fi		
	fi


	colorLine="${line%+([[:blank:]])r[[:digit:]]g[[:digit:]]b[[:digit:]]}"
	
	if [ "$colorLine" == "$line" ]
	then
		indent.sh -$indent echo "'$line'"
		continue
	fi

	colorLine="${colorLine##*([[:blank:]])}"

	indent.sh -$indent echo "color: '$colorLine'"
	

	red="${colorLine%%+([[:blank:]])+([[:digit:]])+([[:blank:]])+([[:digit:]])}"

#echo "  red: '$red'"

	green="${colorLine%%+([[:blank:]])+([[:digit:]])}"
	green="${green##*([[:blank:]])+([[:digit:]])+([[:blank:]])}"

#echo "  green: '$green'"

	blue="${colorLine##*([[:blank:]])+([[:digit:]])+([[:blank:]])+([[:digit:]])+([[:blank:]])}"

#echo "  blue: '$blue'"

	indent.sh -$indent echo "   '$red','$green','$blue'"

	if [ "$doRecurse" == "1" ]
	then
	parseColors 0 "$line" "$fileCat"
		echo "next...?"
		doRecurse=1
	fi

#	IFS="
#"

done

return 0

}


fileCat=`cat LCDdirectLVDS_48c.gpl`

parseColors 1 "" "$fileCat"
