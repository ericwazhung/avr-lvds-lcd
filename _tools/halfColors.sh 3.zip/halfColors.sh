#!/bin/bash

function mergeColors {
local red="$1"
local green="$2"
local blue="$3"
local others="$4"
local red2=""
local green2=""
local blue2=""

IFS="
"
for otherColor in $others
do
#indent.sh -5 echo "$otherColor"
#echo "$otherColor"
	red2="${otherColor%%,+([[:digit:]]),+([[:digit:]])}"
	green2="${otherColor##+([[:digit:]]),}"
	green2="${green2%%,+([[:digit:]])}"
	blue2="${otherColor##+([[:digit:]]),+([[:digit:]]),}"
#echo " '$red2','$green2','$blue2'"


	echo "  $(( (red+red2)/2 )),$(( (green+green2)/2 )),$(( (blue+blue2)/2 ))"

done

return 0
}




function parseColors {
local fileCat="$3"
local startLine="$2"
local doRecurse="$1"
local indent=0
local startLineFound=0
local red=0
local green=0
local blue=0

local line=""
local colorLine=""

if [ "$doRecurse" == "0" ]
then
#echo "looking for '$startLine'"
	indent=3
fi

IFS="
"

shopt -s extglob

for line in $fileCat
do
#echo "$line"

	if [ "$doRecurse" == "0" ]
	then
		if [ "$startLineFound" == "0" ]
		then
			if [ "$line" == "$startLine" ]
			then
#echo "...found"
				startLineFound=1
			fi

			continue
		fi		
	fi


	colorLine="${line%+([[:blank:]])r[[:digit:]]g[[:digit:]]b[[:digit:]]}"
	
	if [ "$colorLine" == "$line" ]
	then
		indent.sh -$indent echo "'$line'"
		continue
	fi

	colorLine="${colorLine##*([[:blank:]])}"

#echo "color: '$colorLine'"
	

	red="${colorLine%%+([[:blank:]])+([[:digit:]])+([[:blank:]])+([[:digit:]])}"

#echo "  red: '$red'"

	green="${colorLine%%+([[:blank:]])+([[:digit:]])}"
	green="${green##*([[:blank:]])+([[:digit:]])+([[:blank:]])}"

#echo "  green: '$green'"

	blue="${colorLine##*([[:blank:]])+([[:digit:]])+([[:blank:]])+([[:digit:]])+([[:blank:]])}"

#echo "  blue: '$blue'"

	echo "$red,$green,$blue"

	if [ "$doRecurse" == "1" ]
	then
		others=`parseColors 0 "$line" "$fileCat"`
		mergeColors $red $green $blue "$others"
		echo "next...?"
#WTF, once the variables in this function are declared, they're reused
#in all recursions?!
#How is it I never ran into this before...?!
# Maybe I've never used a recursive function, and instead had recursive
# calls to script files...?
# Either way, it looks like "local" in the definitions fixes it.
#	doRecurse=1
	fi

#	IFS="
#"

done

return 0

}


fileCat=`cat LCDdirectLVDS_48c.gpl`

parseColors 1 "" "$fileCat"
